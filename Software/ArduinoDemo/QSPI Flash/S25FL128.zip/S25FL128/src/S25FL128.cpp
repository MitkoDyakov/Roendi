/**
  ******************************************************************************
  * @file    S25FL128.c
  * @author  MitkoDyakov
  * @version V1.0.0
  * @date    2-October-2021
  * @brief   S25FL128 library for STM32 Arduino
  *
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

#include "S25FL128.h"

S25FL128Class S25FL128;

S25FL128Class::S25FL128Class(): initDone(0)
{
}

void S25FL128Class::begin(uint8_t data0, uint8_t data1, uint8_t data2, uint8_t data3, uint8_t sclk, uint8_t ssel)
{
  _qspi.pin_d0   = digitalPinToPinName(data0);
  _qspi.pin_d1   = digitalPinToPinName(data1);
  _qspi.pin_d2   = digitalPinToPinName(data2);
  _qspi.pin_d3   = digitalPinToPinName(data3);
  _qspi.pin_sclk = digitalPinToPinName(sclk);
  _qspi.pin_ssel = digitalPinToPinName(ssel);

  if (BSP_QSPI_Init(&_qspi) == MEMORY_OK) 
  {
    initDone = 1;
  }
}

void S25FL128Class::end(void)
{
  BSP_QSPI_DeInit(&_qspi);
  initDone = 0;
}

uint32_t S25FL128Class::write(uint8_t data, uint32_t addr)
{
  return write(&data, addr, 1);
}

uint32_t S25FL128Class::write(uint8_t *pData, uint32_t addr, uint32_t size)
{
  if ((pData == NULL) || (initDone == 0)) {
    return 0;
  }

  if (BSP_QSPI_Write(&_qspi, pData, addr, size) != MEMORY_OK) {
    return 0;
  }

  return size;
}

uint8_t S25FL128Class::read(uint32_t addr)
{
  uint8_t data;

  read(&data, addr, 1);

  return data;
}

void S25FL128Class::read(uint8_t *pData, uint32_t addr, uint32_t size)
{
  if ((pData != NULL) && (initDone == 1)) {
    BSP_QSPI_Read(&_qspi, pData, addr, size);
  }
}

uint8_t *S25FL128Class::mapped(void)
{
  if (BSP_QSPI_EnableMemoryMappedMode(&_qspi) != MEMORY_OK) {
    return NULL;
  }

  return (uint8_t *)MEMORY_MAPPED_ADDRESS;
}

uint8_t S25FL128Class::eraseChip(void)
{
  if (initDone == 0) {
    return MEMORY_ERROR;
  }

  return BSP_QSPI_Erase_Chip(&_qspi);
}

uint8_t S25FL128Class::eraseSector(uint32_t sector)
{
  if (initDone == 0) {
    return MEMORY_ERROR;
  }

  return BSP_QSPI_Erase_Sector(&_qspi, sector);
}

uint8_t S25FL128Class::sleep(void)
{
  if (initDone == 0) {
    return MEMORY_ERROR;
  }

  return BSP_QSPI_EnterDeepPowerDown(&_qspi);
}

uint8_t S25FL128Class::wakeup(void)
{
  if (initDone == 0) {
    return MEMORY_ERROR;
  }

  return BSP_QSPI_LeaveDeepPowerDown(&_qspi);
}

uint8_t S25FL128Class::status(void)
{
  return BSP_QSPI_GetStatus(&_qspi);
}

uint32_t S25FL128Class::info(memory_info_t info)
{
  uint32_t res;
  QSPI_Info pInfo;

  BSP_QSPI_GetInfo(&pInfo);

  switch (info) {
    case MEMORY_SIZE:
      res = pInfo.FlashSize;
      break;

    case MEMORY_SECTOR_SIZE:
      res = pInfo.EraseSectorSize;
      break;

    case MEMORY_SECTOR_NUMBER:
      res = pInfo.EraseSectorsNumber;
      break;

    case MEMORY_PAGE_SIZE:
      res = pInfo.ProgPageSize;
      break;

    case MEMORY_PAGE_NUMBER:
      res = pInfo.ProgPagesNumber;
      break;

    default:
      res = 0;
      break;
  }

  return res;
}

uint32_t S25FL128Class::length(void)
{
  return info(MEMORY_SIZE);
}
