/**
  ******************************************************************************
  * @file    S25FL128.h
  * @brief   This file contains all the description of the S25FL128 QSPI memory.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef _S25FL128_DESC_H_
#define _S25FL128_DESC_H_

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/

/**
  * @brief  S25FL128 Configuration
  */
#define S25FL128_FLASH_SIZE                  (0x1000000u)  /* 128 MBits => 16MBytes */
#define S25FL128_BLOCK_SIZE                  (0x1000u)     /* 4096 sectors of 4kBytes */
#define S25FL128_SECTOR_SIZE                 (0x100u)      /* 256 pages of 256 bytes */
#define S25FL128_PAGE_SIZE                   (0x10000u)    /* 256 blocks of 64KBytes */
                                             
#define S25FL128_DUMMY_CYCLES_READ           (8u)
                                             
#define S25FL128_CHIP_ERASE_MAX_TIME         240000
#define S25FL128_BLOCK_ERASE_MAX_TIME        3500
#define S25FL128_SUBBLOCK_ERASE_MAX_TIME     3000
#define S25FL128_SECTOR_ERASE_MAX_TIME       240
                                             
/**                                          
  * @brief  S25FL128 Commands                
  */                                         
/* Read Operations */                        
#define QUAD_OUTPUT_READ                     (0x6Cu)
                                             
/* Program Operations */                     
#define PAGE_PROGRAM_CMD                     (0x12u)
#define ENTER_4BYTE_ADDRESS                  (0xB7u)
                                             
/* Erase Operations */                       
#define SECTOR_ERASE_CMD                     (0x21u)
#define CHIP_ERASE_CMD                       (0x60u)

/* Identification Operations */
#define READ_ID_CMD                          (0x9Fu)
#define READ_ELECTRONIC_ID_CMD               (0xABu)
#define READ_SERIAL_FLASH_DISCO_PARAM_CMD    (0x5Au)

/* Write Operations */
#define WRITE_ENABLE_CMD                     (0x06u)
#define WRITE_DISABLE_CMD                    (0x04u)

/* Register Operations */
#define READ_STATUS_REG_CMD                  (0x05u)
#define READ_CFG_REG1_CMD                    (0x35u)
#define READ_CFG_REG2_CMD                    (0x15u)
#define WRITE_CFG_REG1_CMD                   (0x01u)
#define WRITE_STATUS_CFG_REG_CMD             (0x01u)

/* Power Down Operations */
#define DEEP_POWER_DOWN_CMD                  (0xB9u)
#define RELEASE_FROM_POWER_DOWN              (0xABu)

/* No Operation */
#define NO_OPERATION_CMD                     (0x00u)

/* Reset Operations */
#define RESET_ENABLE_CMD                     (0x66u)
#define RESET_MEMORY_CMD                     (0x99u)
#define RELEASE_READ_ENHANCED_CMD            (0xFFu)

/**
  * @brief  S25FL128 Registers
  */
/* Status Register */
#define S25FL128_SR_WIP                    ((uint8_t)0x01)    /*!< Write in progress */
#define S25FL128_SR_WEL                    ((uint8_t)0x02)    /*!< Write enable latch */
#define S25FL128_SR_BP                     ((uint8_t)0x3C)    /*!< Block protect */
#define S25FL128_SR_QE                     ((uint8_t)0x20)    /*!< Quad enable */
#define S25FL128_SR_SRWD                   ((uint8_t)0x80)    /*!< Status register write disable */

/* Configuration Register 2 */
#define S25FL128_CR2_4BYTE_ADR_BIT         ((uint8_t)0x02)    /*!< 4byte address indicator bit */

#ifdef __cplusplus
}
#endif

#endif /* _S25FL128_DESC_H_ */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
