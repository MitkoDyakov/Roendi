# S25FL128
Arduino library to support the Quad-SPI NOR Flash memory S25FL128 using the Quad SPI flash memories interface.

## API

The library provides the following API:

* `begin()`
* `end()`
* `write()`
* `read()`
* `mapped()`
* `eraseChip()`
* `eraseSector()`
* `sleep()`
* `wakeup()`
* `status()`
* `info()`
* `length()`

Since library version 2.0.0, xSPI pins can be defined at sketch level, using:

* To redefine the default one before call of `begin()`:

  * `setDx(uint32_t data0, uint32_t data1, uint32_t data2, uint32_t data3)`
  * `setDx(PinName data0, PinName data1, PinName data2, PinName data3)`
  * `setSSEL(uint32_t ssel)`
  * `setSSEL(PinName ssel)`
  * `setSCLK(uint32_t sclk)`
  * `setSCLK(PinName sclk)`

  *Code snippet:*
```C++
  S25FL128.setDx(PB1, PB0, PA7, PA6); // using pin number
  S25FL128.setSCLK(PE10);
  S25FL128.setSSEL(PE_11); // using PinName
  S25FL128.begin();
```

* or using the `begin()` method:

  * `S25FL128Class(uint8_t data0, uint8_t data1, uint8_t data2, uint8_t data3, uint8_t clk, uint8_t ssel)`

  *Code snippet:*
```C++
  S25FL128.begin(PB1, PB0, PA7, PA6, PA3, PB11);
```

* or by redefining the default pins definition 

  * `S25FL128_D0`
  * `S25FL128_D1`
  * `S25FL128_D2`
  * `S25FL128_D3`
  * `S25FL128_SCLK`
  * `S25FL128_SSEL`

## Examples

3 sketches provide basic examples to show how to use the library API:
* `demo.ino` uses basic read/write functions.
* `eraseChip.ino` erases all data present in the memory.
* `memoryMappedMode.ino` shows how to use the mapped mode.

## Documentation

You can find the source files at  
[TODO]
The S25FL128 datasheet is available at  
[TODO]
